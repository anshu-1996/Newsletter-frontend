import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreatetempComponent } from './createtemp/createtemp.component';
import { EditTemplateComponent } from './edit-template/edit-template.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { MydocComponent } from './mydoc/mydoc.component';
import { MyprofileComponent } from './myprofile/myprofile.component';
import { SignupComponent } from './signup/signup.component';




const routes: Routes = [
  {path:'', component:HomeComponent,data:{animation:''}},
  {path: 'home', component: HomeComponent,data:{animation:'home'}},
  {path:'login', component:LoginComponent,data:{animation:'login'}},
  {path: 'signup',component:SignupComponent,data:{animation:'signup'}},
  {path: 'createtemp',component:CreatetempComponent,data:{animation:'createtemp'}},
  {path: 'edit-template', component:EditTemplateComponent,data:{animation:'edit-template'}},
  {path: 'mydoc', component:MydocComponent,data:{animation:'mydoc'}},
  {path: 'myprofile', component:MyprofileComponent,data:{animation:'myprofile'}},
  {path: '**', redirectTo: 'home',data:{animation:'home'}},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
