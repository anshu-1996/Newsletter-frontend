export class User {
  username: String = '';
  password: String = '';
  fullName: String = '';
}
export class Myprofile{
  username: String = '';
  password: String = '';
  fullName: String = '';
  phone: String = '';
}
export class achievementTemp {
  title: String = 'Title';
  date: String = '';
  achievement1: String[] = ['', '', ''];
  constructor(title: String, date: String, achievement1: String[]) {}
}

interface KeyValuePair {
  key: string;
  value: string;
}


export class newjoinTemp {
  type: string = 'new joinees';
  title: string = '';
  date: string = '';

  pair: any = [
    { first: 'Joinee name ', second: 'Joinee info here' },
    { first: 'Joinee name ', second: 'Joinee info here' },
    { first: 'Joinee name ', second: 'Joinee info here' },
    { first: 'Joinee name ', second: 'Joinee info here' },
  ];

  constructor(title: string, date: string, pair: any) {}
}
