import { Component, OnInit } from '@angular/core';
import { TemplateService } from '../template.service';
import { newjoinTemp } from '../user';
import { UserRegistrationService } from '../user-registration.service';

@Component({
  selector: 'app-newjoiners',
  templateUrl: './newjoiners.component.html',
  styleUrls: ['./newjoiners.component.scss']
})
export class NewjoinersComponent implements OnInit {


templateId:number = 0;
template : newjoinTemp = new newjoinTemp('','',[])
file:any;
  constructor(private service : UserRegistrationService,private templateService: TemplateService) {
  }

  ngOnInit(): void {
    this.templateService.fileUploaded.subscribe(()=>{
      // console.log(30);
      if(this.templateService.template===4){
        this.file = this.templateService.getFile();
        this.setDataByFile()
      }
    })
    this.templateService.save.subscribe(()=>{
      if(this.templateService.template===4){
        const data = {'templateType':'new joinees','createdBy':localStorage.getItem('username'),'title':this.template.title,'joiningDate':this.template.date,'joinees':this.template.pair};
        this.templateService.onTemplateSave(data,this.templateId).subscribe((data)=>{
          this.file = data;
          this.templateId = this.file.templateId;
        });
      }
    })
  }
  setDataByFile() {
    if(this.templateId===0){
      this.templateId = this.file.templateId;
    }
    this.template.date = this.file.joiningDate;
    this.template.title = this.file.title;
    this.template.pair = this.file.joinees;
  }

  // subscribe the save button event on edit template
  onSave()
  {
    this.service.saveTemplate(this.template)
  }




}
