import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewjoinersComponent } from './newjoiners.component';

describe('NewjoinersComponent', () => {
  let component: NewjoinersComponent;
  let fixture: ComponentFixture<NewjoinersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewjoinersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NewjoinersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
