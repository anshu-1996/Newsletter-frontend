import { Component, OnInit } from '@angular/core';
import { ArrowRightAltOutlined } from '@material-ui/icons';
import { TemplateService } from '../template.service';
import { Updates } from '../updates';

@Component({
  selector: 'app-updatestemplate',
  templateUrl: './updatestemplate.component.html',
  styleUrls: ['./updatestemplate.component.scss']
})
export class UpdatestemplateComponent implements OnInit {
  templateId:number = 0;
  up : Updates= new Updates("","","","")
  file:any;
  constructor(private templateService:TemplateService) { }

  ngOnInit(): void {
    this.templateService.fileUploaded.subscribe(()=>{
      // console.log(30);
      if(this.templateService.template===2){
        this.file = this.templateService.getFile();
        this.setDataByFile();
      }
    })
    this.templateService.save.subscribe(()=>{
      // console.log(20);
      if(this.templateService.template===2){
        const data = {'templateType':'meeting','meetingHeldOn':this.up.date,'meetingHeldBy':this.up.person,'organizedAt':'office','subheader':this.up.subheader,'content':this.up.content,'createdBy':localStorage.getItem('username')};
        console.log(data);
        this.templateService.onTemplateSave(data,this.templateId).subscribe();
      }
    })
  }
  setDataByFile() {
    if(this.templateId===0){
      this.templateId = this.file.templateId;
    }
    // console.log(this.file);
    this.up.content = this.file.content;
    // console.log(this.up.content);
    this.up.date = this.file.meetingHeldOn;
    this.up.person = this.file.meetingHeldBy;
    this.up.subheader = this.file.subheader;
  }

}
