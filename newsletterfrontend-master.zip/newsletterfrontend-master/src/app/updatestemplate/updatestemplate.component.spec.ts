import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatestemplateComponent } from './updatestemplate.component';

describe('UpdatestemplateComponent', () => {
  let component: UpdatestemplateComponent;
  let fixture: ComponentFixture<UpdatestemplateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdatestemplateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatestemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
