import { Component, Input, OnInit } from '@angular/core';
import { TemplateService } from '../template.service';
import { User } from '../user';
import { UserRegistrationService } from '../user-registration.service';

@Component({
  selector: 'app-hiring-template',
  templateUrl: './hiring-template.component.html',
  styleUrls: ['./hiring-template.component.scss']
})
export class HiringTemplateComponent implements OnInit {


  templateId:number = 0;
  templateType:string = "job openings";
  companyName:string = "Company Name";
  jobPortalName:string = "name@hr.com";
  websiteUrl:string = "www.companyname.com";
  vacancies: string[] = [];
  date: string = "yyyy-mm-dd";
  add: boolean = false;
  file:any;
  fileUpload:any;
  @Input() preview:boolean=true;
  templateService:TemplateService;
  userService:UserRegistrationService;
  constructor(templateService:TemplateService,userService:UserRegistrationService) {
    this.templateService = templateService;
    this.userService = userService;
   }

  ngOnInit(): void {
    // console.log("yes");
    this.fileUpload = this.templateService.fileUploaded.subscribe(()=>{
      // console.log(30);
      if(this.templateService.template===5){
        this.file = this.templateService.getFile();
        this.setDataByFile();
      }
    })
    this.templateService.save.subscribe(()=>{
      // console.log(20);
      if(this.templateService.template===5){
        const data = {'companyName':this.companyName,'jobPortalName':this.jobPortalName,'templateType':this.templateType,'websiteUrl':this.websiteUrl,'vacancies':this.vacancies,'deadline':this.date,'createdBy':localStorage.getItem('username')};
        this.templateService.onTemplateSave(data,this.templateId).subscribe((data)=>{
          this.file = data;
          this.templateId = this.file.templateId;
        });
      }
    })

  }
  // ngOnDestroy() {
  //   this.fileUpload.unsubscribe();
  //   }


  indextracker(index:number,value:any){
    return index;
  }

  onAdd(){
    this.add = true;
    this.vacancies.push("");
  }
  onMinus(index:any){
    this.vacancies.splice(index,1);
  }
  setDataByFile(){
    if(this.templateId===0){
      this.templateId = this.file.templateId;
    }
    this.templateType = this.file.templateType;
    this.companyName = this.file.companyName;
    this.jobPortalName = this.file.jobPortalName;
    this.websiteUrl = this.file.websiteUrl;
    this.vacancies = this.file.vacancies;
    this.date = this.file.deadline;
  }

}
