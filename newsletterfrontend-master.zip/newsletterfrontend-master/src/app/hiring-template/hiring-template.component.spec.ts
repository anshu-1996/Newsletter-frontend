import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HiringTemplateComponent } from './hiring-template.component';

describe('HiringTemplateComponent', () => {
  let component: HiringTemplateComponent;
  let fixture: ComponentFixture<HiringTemplateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HiringTemplateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HiringTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
