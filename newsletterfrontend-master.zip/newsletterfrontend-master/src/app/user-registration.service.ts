import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Login } from './login';
import { User } from './user';

import {  throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class UserRegistrationService {





  loginchanged = new Subject<void>();
  public isError:boolean=false;
  pagechanged = new Subject<boolean>();
  jwt:any = localStorage.getItem('jwt');
  login:Login = {username:"",password:""};
  user : User = {username : "", password : "", fullName : ""};
  username:string = "";
  constructor(private http : HttpClient) { }


  errorHandle(response: HttpErrorResponse) {

    if (response.status === 403) {

      console.log("403")

    }

    return throwError("erroring");

    }


  // update user by username in my-profile
  saveTemplate(template_data: any) {

    var token = 'Bearer ' + this.jwt;
    // console.log(token);
    return this.http.post("https://newsletterbackend-amxbp6pvia-el.a.run.app/Template/add",template_data,{
      headers: new HttpHeaders({
        'Content-Type':'application/json; charset=utf-8',
        'Authorization': `Bearer ${this.jwt.jwt}`
      })
    })

  }
  // update user by username in my-profile
  updateUserdetails(user: any) {

    var token = 'Bearer ' + this.jwt;
    // console.log(token);
    return this.http.put("https://newsletterbackend-amxbp6pvia-el.a.run.app/updateUser/"+localStorage.getItem('username'),user,{
      headers: new HttpHeaders({
        'Content-Type':'application/json; charset=utf-8',
        'Authorization': `Bearer ${localStorage.getItem('jwt')}`
      })
    })


  }

  // getAllUser(){
  //   console.log(this.jwt);
  //   var token = 'Bearer ' + this.jwt;
  //   console.log(token);
  //   return this.http.get("https://newsletterbackend-amxbp6pvia-el.a.run.app/getAllUser",{
  //     headers: new HttpHeaders({
  //       'Content-Type':'application/json; charset=utf-8',
  //       'Authorization': `Bearer ${this.jwt.jwt}`
  //     })
  //   })
  // }

  loginSuccessful() {
    this.loginchanged.next();
  }

  getAutheticate(username:any,password:any){



    this.login.username = username;

    this.login.password = password;

    let res: any;

      res= this.http.post<String>("https://newsletterbackend-amxbp6pvia-el.a.run.app/authenticate", this.login).pipe(catchError(this.errorHandle))

    return res;



  }
  signup(fullname : any, email : any, password : any) {
    this.user.username = email;
    this.user.fullName = fullname;
    this.user.password = password;

    return this.http.post<String>("https://newsletterbackend-amxbp6pvia-el.a.run.app/addUser", this.user);

  }
  getUser(){
    // console.log(this.jwt);
    var token = 'Bearer ' + this.jwt;
    var jwt = localStorage.getItem('jwt');
    // console.log(localStorage.getItem('jwt'));
    var url = "https://newsletterbackend-amxbp6pvia-el.a.run.app/getUserByUsername/" + localStorage.getItem('username');
    // console.log(token);
    return this.http.get(url,{
      headers: new HttpHeaders({
        'Content-Type':'application/json; charset=utf-8',
        'Authorization': `Bearer ${jwt}`
      })
    })
  }
  pageChanged(status:boolean){
    this.pagechanged.next(status);
  }
}
