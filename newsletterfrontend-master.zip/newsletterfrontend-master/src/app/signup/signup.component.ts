import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserRegistrationService } from '../user-registration.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {

  fullname:any;
  email:any;
  password:any;
  showModal:boolean=false;
  route: ActivatedRoute;
  router: Router;
  userService: UserRegistrationService;
  constructor(userService:UserRegistrationService, route: ActivatedRoute, router: Router) {
    this.userService = userService;
    this.route = route;
    this.router = router;
   }

  ngOnInit(): void {

  }

  addUser(form:any){
    this.fullname = form.value.fullname;
    this.email = form.value.email;
    this.password = form.value.password;
    this.userService.signup(this.fullname,this.email,this.password).subscribe((data: any)=>{
      // console.log(data);
      this.userService.jwt = data;
      localStorage.setItem('loggedIn','true');
      localStorage.setItem('jwt',this.userService.jwt.jwt);
      localStorage.setItem('username',this.email);
      this.userService.username = this.email;
      this.showModal=true;

      this.userService.pageChanged(true);
      this.userService.loginSuccessful();
      setTimeout(() => {
        this.navigate();
      }, 100)
    })

  }
  navigate(){
    this.router.navigate(['/home']);
  }

}
