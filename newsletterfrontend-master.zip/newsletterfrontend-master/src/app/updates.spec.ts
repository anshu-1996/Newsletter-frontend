import { Updates } from './updates';

describe('Updates', () => {
  it('should create an instance', () => {
    expect(new Updates()).toBeTruthy();
  });
});
