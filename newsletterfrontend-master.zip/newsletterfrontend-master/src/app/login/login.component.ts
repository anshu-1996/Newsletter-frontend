
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { UserRegistrationService } from '../user-registration.service';
import 'rxjs/add/operator/catch';
import { HighlightSharp } from '@material-ui/icons';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  username:any;
  password:any;

  show:boolean=false;
  showModal:boolean=false;
  route: ActivatedRoute;
  router: Router;
  userService: UserRegistrationService;
  isError: boolean=false;
  constructor(userService:UserRegistrationService, route: ActivatedRoute, router: Router) {
    this.userService = userService;
    this.route = route;
    this.router = router;
   }

  ngOnInit(): void {
    this.show=false;
    this.isError=false;

  }


  onlogin(form:any){


    this.show = true;


    this.username = form.value.username;
    this.password = form.value.password;
    let res= this.userService.getAutheticate(this.username, this.password);



    res.subscribe((data:any) => {
     this.userService.jwt = data;

     this.userService.username = this.username;
     localStorage.setItem('loggedIn','true');
     localStorage.setItem('jwt',this.userService.jwt.jwt);
     localStorage.setItem('username',this.username);
     this.showModal=true;

     this.userService.pageChanged(true);
     this.userService.loginSuccessful();

     this.show = false;
     setTimeout(
       () => this.navigate(),
       1000
     );

   }, (error: any) => {
    this.show = false;
    this.isError = true;

      console.log(error)

      if (error.message === "erroring") {

        alert("erroring")

      }else

      alert("Username or Password incorrect");

    });

  }

  navigate(){
    this.router.navigate(['/home']);
  }
}
