import { Fun } from './fun';

describe('Fun', () => {
  it('should create an instance', () => {
    expect(new Fun()).toBeTruthy();
  });
});
