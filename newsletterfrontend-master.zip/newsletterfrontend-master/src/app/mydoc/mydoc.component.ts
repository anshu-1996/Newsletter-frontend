import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TemplateService } from '../template.service';

@Component({
  selector: 'app-mydoc',
  templateUrl: './mydoc.component.html',
  styleUrls: ['./mydoc.component.scss']
})
export class MydocComponent implements OnInit {
current:any;
templates:any = [];
changeSelected(){

}
  constructor(private templateService:TemplateService,private router:Router) { }

  ngOnInit(): void {
    if(localStorage.getItem('loggedIn')!='true')
    this.router.navigate(['/home'])
    this.templateService.getAllTemplates().subscribe((data)=>{
      this.templates = data;
    })
  }
    clickTemp1(e1:any){

      //code
   this.current=e1.target.id;
    }

    clickTemp2(e2:any){

      //code
   this.current=e2.target.id;
    }
    onClick(template:any){
      // console.log(template);
      if(template.templateType==='fun'){
         this.templateService.mydocselected(template);
      }
      if(template.templateType==='meeting'){
        this.templateService.changeTemplate(2);
      }
      if(template.templateType==='achievement'){
        this.templateService.changeTemplate(3);
      }
      if(template.templateType==='new joinees'){
        this.templateService.changeTemplate(4);
      }
      if(template.templateType==='job openings'){
        this.templateService.changeTemplate(5);
      }
      // console.log(template);
      this.navigate();
      setTimeout(()=>{
        // console.log(template);
        this.templateService.setTemplateData(template);
        100})
    }
  navigate() {
    this.router.navigate(['/edit-template'])
  }
}
