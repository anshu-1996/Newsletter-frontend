import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import { Router } from '@angular/router';
import { TemplateService } from '../template.service';

@Component({
  selector: 'app-createtemp',
  templateUrl: './createtemp.component.html',
  styleUrls: ['./createtemp.component.scss']
})
export class CreatetempComponent implements OnInit {
  current:any;
//  event:number | undefined;

templateService:TemplateService;
show1:boolean=false
show2:boolean=false
show3:boolean=false
show4:boolean=false
show5:boolean=false
show6:boolean=false

// $('img').click(function(){


// });
changeSelected(){

}

  constructor(templateService:TemplateService,private route: Router) {
    this.templateService = templateService;
   }

  ngOnInit(): void {
    if(localStorage.getItem('loggedIn')!='true')
    this.route.navigate(['/login'])
  }
  clickTemp1(e1:any){
    this.show1=true;
    this.show2=false;
    this.show3=false;
    this.show4=false;
    this.show5=false;
    this.show6=false;
    //code
 this.current=e1.target.id;
 this.templateService.changeTemplate(1);
//  console.log(this.current);
  }
  clickTemp2(e2:any){
    this.show1=false;
    this.show2=true;
    this.show3=false;
    this.show4=false;
    this.show5=false;
    this.show6=false;
    this.current=e2.target.id;
    this.templateService.changeTemplate(2);
  }
  clickTemp3(e3:any){
    this.show1=false;
    this.show2=false;
    this.show3=true;
    this.show4=false;
    this.show5=false;
    this.show6=false;
    this.current=e3.target.id;
    this.templateService.changeTemplate(3);
  }
  clickTemp4(e4:any){
    this.show1=false;
    this.show2=false;
    this.show3=false;
    this.show4=true;
    this.show5=false;
    this.show6=false;
    this.current=e4.target.id;
    this.templateService.changeTemplate(4);
  }
  clickTemp5(e5:any){
    this.show1=false;
    this.show2=false;
    this.show3=false;
    this.show4=false;
    this.show5=true;
    this.show6=false;
    this.current=e5.target.id;
    this.templateService.changeTemplate(5);
  }
  clickTemp6(e6:any){
    this.show1=false;
    this.show2=false;
    this.show3=false;
    this.show4=false;
    this.show5=false;
    this.show6=true;
    this.current=e6.target.id;
    this.templateService.changeTemplate(6);
  }

}


