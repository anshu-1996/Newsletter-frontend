import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LeadershipTemplateComponent } from './leadership-template.component';

describe('LeadershipTemplateComponent', () => {
  let component: LeadershipTemplateComponent;
  let fixture: ComponentFixture<LeadershipTemplateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LeadershipTemplateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LeadershipTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
