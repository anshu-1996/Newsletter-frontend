import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leadership-template',
  templateUrl: './leadership-template.component.html',
  styleUrls: ['./leadership-template.component.scss']
})
export class LeadershipTemplateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
