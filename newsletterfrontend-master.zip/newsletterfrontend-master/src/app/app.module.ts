import { NgModule, CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreatetempComponent } from './createtemp/createtemp.component';
import { MydocComponent } from './mydoc/mydoc.component';
import { FuntemplateComponent } from './funtemplate/funtemplate.component';
import { UpdatestemplateComponent } from './updatestemplate/updatestemplate.component';
import { FormsModule } from '@angular/forms';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { MyprofileComponent } from './myprofile/myprofile.component';
import { AchievementTemplateComponent } from './achievement-template/achievement-template.component';
import { NewjoinersComponent } from './newjoiners/newjoiners.component';
import { HeaderComponent } from './header/header.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatIconModule} from '@angular/material/icon';
import {MatSelectModule} from '@angular/material/select';
import { HomeComponent } from './home/home.component';
import { EditTemplateComponent } from './edit-template/edit-template.component';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from "@angular/material/form-field"
import { UserRegistrationService } from './user-registration.service';
import { HttpClientModule } from '@angular/common/http';
import { TemplateService } from './template.service';
import { LeadershipTemplateComponent } from './leadership-template/leadership-template.component';
import { HiringTemplateComponent } from './hiring-template/hiring-template.component';

@NgModule({
  declarations: [
    AppComponent,
    CreatetempComponent,
    MydocComponent,
    FuntemplateComponent,
    UpdatestemplateComponent,
    SignupComponent,
    LoginComponent,
    MyprofileComponent,
    AchievementTemplateComponent,
    NewjoinersComponent,
    HeaderComponent,
    HomeComponent,
    EditTemplateComponent,
    LeadershipTemplateComponent,
    HiringTemplateComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatIconModule,
    FormsModule,
    HttpClientModule,
    MatSelectModule,
    MatFormFieldModule,
    MatInputModule,
  ],

  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [UserRegistrationService,TemplateService],
  bootstrap: [AppComponent]
})
export class AppModule { }
