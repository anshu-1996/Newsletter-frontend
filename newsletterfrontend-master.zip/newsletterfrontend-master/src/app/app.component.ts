import { Component } from '@angular/core';
import { Event, NavigationEnd, Router, RouterEvent } from '@angular/router';
import { UserRegistrationService } from './user-registration.service';
import { filter } from 'rxjs/operators';
import { slideAnimations } from './app-routing.animation';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  animations: [slideAnimations]
})
export class AppComponent {
  title = 'newsletter';
  loggedIn = false;
  flag:Boolean = true;
  userService : UserRegistrationService;
  router:Router;
  constructor(userService: UserRegistrationService,router:Router){
    this.userService = userService;
    this.router = router;
    // this.router.events.subscribe((event:Event) => {
    //   if(event instanceof NavigationEnd) {

    //   }
    // });
    this.router.events.pipe(
      filter((e: Event): e is NavigationEnd => e instanceof NavigationEnd)).subscribe((e:NavigationEnd) => {
        if(e.url=='/login' || e.url=='/signup'){
          this.flag = false;
        }
        else{
          this.flag = true;
        }
   });
  }
  ngOnInit(): void{
    this.userService.pagechanged.subscribe(
      (pagechanged)=>{
        // console.log(pagechanged);
        this.flag = pagechanged;
    });
  }
  changeStatus(status:any){
    console.log(status);
    this.loggedIn = status;
  }
  displayChange(status:Boolean){

    this.flag = status;
  }
}
