import {
  transition,
  trigger,
  query,
  style,
  animate,
  group,
  stagger,
  animateChild,
  keyframes
} from '@angular/animations';

export const slideAnimations =
trigger('routeAnimations',[
  transition('* => *', [
group([
  query(':enter .container', stagger(2000, [
    style({
      left:0,
      width:'100%',
       opacity:0,
      position:'relative',
      transform:'scale(0) translateY(100%)',

   }),
    animate('600ms ease', style({
    transform:'scale(1) translateY(0%)' ,opacity:1})),
  ]), { optional: true }),

  query(':enter .logotext', stagger(2000, [
    style({   transform:'translateY(0%)' }),
    animate('0.5s', style({   transform:'rotateY(-180deg)' })),
  ]), { optional: true })
])
]) ,


    transition('* => playboard', [
      group([
        query(':enter .board1', stagger(2000, [
          style({  transform:'translateX(150%)',
          opacity:0.2 }),
          animate('0.5s', style({
            transform:'translateX(0%)' })),
        ]), { optional: true }),
        query(':enter .board2', stagger(2000, [
          style({  transform:'translateX(110%)',
          opacity:0.2}),
          animate('0.5s', style({
            transform:'translateX(0%)' })),
        ]), { optional: true }),
        query(':enter .board3', stagger(2000, [
          style({  transform:'translateX(-60%)',
          opacity:0.2 }),
          animate('0.5s', style({
            transform:'translateX(0%)' })),
        ]), { optional: true }),
        query(':enter .board4', stagger(2000, [
          style({  transform:'translateX(-110%)',
          opacity:0.2 }),
          animate('0.5s', style({
            transform:'translateX(0%)' })),
        ]), { optional: true })
        ,
        query(':enter .playbtn', stagger(2000, [
          style({  transform:'translateY(70%)',
          opacity:0.2 }),
          animate('0.5s', style({
            transform:'translateX(0%)' })),
        ]), { optional: true })
      ])

  ]),
  transition('* => mainboard', [
    group
      ([
        query(':enter .Chip1', stagger(2000, [
          style({  transform:'translateY(-50px)',
          opacity:0.2 }),
          animate('10s', style({
            transform:'translateY(0%)',opacity:1 })),
        ]), { optional: true }),
        query(':enter .Chip2', stagger(2000, [
          style({  transform:'translateY(-110%)',
          opacity:0.2}),
          animate('1s', style({
            transform:'translateY(0%)',opacity:1 })),
        ]), { optional: true }),
        query(':enter .Chip3', stagger(2000, [
          style({  transform:'translateY(-200%)',
          opacity:0.2 }),
          animate('1s', style({
            transform:'translateY(0%)',opacity:1 })),
        ]), { optional: true })

      ])

  ])
])
