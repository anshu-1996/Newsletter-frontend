export class Updates {
date:String='';
    subheader:String = '';
    person:String = '';
    content:String = '';
    constructor(
      date:string,
      subheader:string,
      person:string,
      content:string
    ){
      this.date=date
      this.subheader = subheader
      this.person = person
      this.content = content
    }


}
