import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { UserRegistrationService } from './user-registration.service';

@Injectable({
  providedIn: 'root'
})
export class TemplateService {

  template:number = 5;
  templateData:any;
  fileUploaded = new Subject<void>();
  save = new Subject<void>();
  http:HttpClient;
  userService: UserRegistrationService;
  baseurl:string = "https://newsletterbackend-amxbp6pvia-el.a.run.app/";
  constructor(http:HttpClient ,userService:UserRegistrationService) {
    this.http = http;
    this.userService = userService;
  }
  changeTemplate(template:number){
    this.template = template;
    // console.log(this.template);
  }
  uploadDocx(file:File){
    var url = this.baseurl + localStorage.getItem('username') +  "/uploadFile";
    var jwt = localStorage.getItem('jwt');
    const fd = new FormData();
    fd.append('File',file,file.name);
    return this.http.post(url,fd,{
      headers: new HttpHeaders({
        'Authorization': `Bearer ${jwt}`
      })
    });
  }
  setTemplateData(file:File){
    // console.log(files);
    this.templateData = file;
    this.fileUploaded.next();
  }
  getFile(){
    return this.templateData;
  }
  onSave(){
    this.save.next();
  }
  onTemplateSave(data:any,templateId:number){
    if(templateId===0){
      var url = this.baseurl + localStorage.getItem('username') + "/Template/add";
      // console.log(data);

      return this.http.post(url,data,{
        headers: new HttpHeaders({
          'Authorization': `Bearer ${localStorage.getItem('jwt')}`
        })
      })
    }
    else{
      var url = this.baseurl + "Template/update/" + templateId;
      // console.log(data);

      return this.http.put(url,data,{
        headers: new HttpHeaders({
          'Authorization': `Bearer ${localStorage.getItem('jwt')}`
        })
      })
    }
  }
  getAllTemplates(){
    var url = this.baseurl + "getDocuments/" + localStorage.getItem('username');
    // console.log(localStorage.getItem('jwt'));
    return this.http.get(url,{
      headers: new HttpHeaders({
        'Authorization': `Bearer ${localStorage.getItem('jwt')}`
      })
    })
  }

  mydocselected(template: any) {

  }

}
