import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { TemplateService } from '../template.service';
import { UserRegistrationService } from '../user-registration.service';
import * as htmlToImage from 'html-to-image';
import { toPng, toJpeg, toBlob, toPixelData, toSvg } from 'html-to-image';
import download from 'downloadjs';
import {saveAs} from 'file-saver';
@Component({
  selector: 'app-edit-template',
  templateUrl: './edit-template.component.html',
  styleUrls: ['./edit-template.component.scss']
})
export class EditTemplateComponent implements OnInit {

  template:number = 1;
  show:boolean=false;
  showModal:boolean=false;
  userService: UserRegistrationService;
  templateService: TemplateService;
  route: ActivatedRoute;
  router: Router;
  file:any;
  templateData:any;
  url:any;
  preview:boolean=false;
  download:boolean=false;
  constructor(userService:UserRegistrationService,templateService:TemplateService,route: ActivatedRoute,router: Router) {
    this.userService = userService;
    this.templateService = templateService;
    this.route = route;
    this.router = router;
  }

  ngOnInit(): void {
    this.show=false;
    if(localStorage.getItem('loggedIn')!='true')
    this.router.navigate(['/home'])
    // if(this.userService.loggedIn===false)
    //   this.router.navigate(["/home"]);
    this.template = this.templateService.template;
    // if(this.userService.loggedIn===false){
    //   this.router.navigate(["/home"]);
    // }
  }
  onDownload(){
    this.preview = true;
    this.download = true;
    setTimeout(()=>{
      this.generatePDF();
      },100)
  }
  generatePDF() {
    const data = document.getElementById('template')!;
    htmlToImage.toPng(data)
  .then(function (dataUrl) {
    download(dataUrl, 'my-node.png');
  });

  }
  generatepreview(){
    var data = document.getElementById('template')!;
    htmlToImage.toPng(data)
  .then( (dataUrl) => {
    this.url = dataUrl;
  })
  .catch(function (error) {
    console.error('oops, something went wrong!', error);
  });
  }
  // generatepreview(){
  //   const data = document.getElementById('template')!;
  //   html2canvas(data).then(canvas => {
  //     var imgWidth = 208;
  //     var imgHeight = canvas.height * imgWidth / canvas.width;
  //     const contentDataURL = canvas.toDataURL('image/png');
  //     this.url = contentDataURL;
  //     // console.log(this.url);
  //   });
  // }
  onClick(status:boolean){
    this.preview = status;
    this.download = false;
    setTimeout(()=>{
    if(status===true){
      this.generatepreview();
    }
  },100)
  }
  onUpload(file:any){
    this.show=true;
    this.file = <File>file.target.files[0];
    // console.log(this.file);
    if(file!==undefined){
      this.templateService.uploadDocx(this.file).subscribe((data)=>{
        this.show=false;
        this.templateData = data;
        this.templateService.setTemplateData(this.templateData);
        // console.log(data);

      });
  }
  }
  onSave(){

     this.templateService.onSave();
     this.showModal=true;
  }

  // docxtopdf(){
  // const path = require('path');
  // const unoconv = require('awesome-unoconv');
  // //Place your word file in source
  // const sourceFilePath = path.resolve('./word_file.docx');
  // const outputFilePath = path.resolve('./myDoc.pdf');

  // unoconv
  //   .convert(sourceFilePath, outputFilePath)
  //   .then(result=> {
  //     console.log(result); // return outputFilePath
  //   })
  //   .catch(err => {
  //     console.log(err);
  //   });
  // }
}
