export class Fun {
  topic:String = '';
  content:String = '';
  venue:String = '';
  constructor(
    topic:string,
    content:string,
    venue:string
  ){
    this.topic = topic
    this.topic = topic
  }

}
