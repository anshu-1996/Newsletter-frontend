import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FuntemplateComponent } from './funtemplate.component';

describe('FuntemplateComponent', () => {
  let component: FuntemplateComponent;
  let fixture: ComponentFixture<FuntemplateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FuntemplateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FuntemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
