import { Component, OnInit } from '@angular/core';
import { Fun } from '../fun';
import { TemplateService } from '../template.service';
@Component({
  selector: 'app-funtemplate',
  templateUrl: './funtemplate.component.html',
  styleUrls: ['./funtemplate.component.scss']
})
export class FuntemplateComponent implements OnInit {
  templateId:number = 0;
   fun : Fun= new Fun("","","")
   file:any;
  constructor(private templateService:TemplateService) { }

  ngOnInit(): void {
    this.templateService.fileUploaded.subscribe(()=>{
      // console.log(30);
      if(this.templateService.template===1){
        this.file = this.templateService.getFile();
        this.setDataByFile();
      }
    })
    this.templateService.save.subscribe(()=>{
      // console.log(20);
      if(this.templateService.template===1){
        const data = {'templateType':'fun','eventName':this.fun.topic,'eventDescription':this.fun.content,'venue':this.fun.venue,'eventOn':'2021-09-09','createdBy':localStorage.getItem('username')};
        this.templateService.onTemplateSave(data,this.templateId).subscribe((data)=>{
          this.file = data;
          this.templateId = this.file.templateId;
        });
      }
    })
  }
  setDataByFile() {
    if(this.templateId===0){
      this.templateId = this.file.templateId;
    }
    this.fun.content = this.file.content;
    this.fun.topic = this.file.topic;
    this.fun.venue = this.file.venue;
  }

}
