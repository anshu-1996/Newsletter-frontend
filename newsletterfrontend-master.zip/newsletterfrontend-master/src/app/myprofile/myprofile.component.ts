import { Component, OnInit } from '@angular/core';
import { UserRegistrationService } from '../user-registration.service';


import { Router } from '@angular/router';
import { Myprofile } from '../user';

@Component({
  selector: 'app-myprofile',
  templateUrl: './myprofile.component.html',
  styleUrls: ['./myprofile.component.scss']
})
export class MyprofileComponent implements OnInit {

  content:boolean=false;
  edit:boolean=true;
  user:any;
  save:boolean=false;
  disabled:boolean=true;
  username:any;
  showModal:boolean=false;
  curr_user:any  = {'fullName':'','username':'','password':''};
  update_user: Myprofile = {username:'',password:'',phone:'',fullName:''};

  constructor(private service:UserRegistrationService,private route:Router ) { }

  ngOnInit(): void {
    if(localStorage.getItem('loggedIn')!='true')
    this.route.navigate(['/home'])
    let resp = this.service.getUser();
    resp.subscribe(((data: any)=>{
      // console.log(data);
      this.curr_user=data
    }));
    // for(let i=0;i<this.user.length();i++){
    //   if(this.user[i].username == this.username)
    //       {this.curr_user= this.user[i];break;}

    // }
    // console.log(localStorage.getItem('username'));
  }

  onEdit(){
    this.content = true;
    this.edit=false;
    this.save=true;
    this.disabled = false;
    this.update_user.fullName = this.curr_user.fullName;
    // console.log(this.save);

  }
  onSave(){

    this.content = false;
    this.save=false;
    this.edit=true;
    this.disabled = true;
    this.username = localStorage.getItem('username');
    this.showModal = true;
    this.service.updateUserdetails(this.update_user).subscribe();


  }



}
