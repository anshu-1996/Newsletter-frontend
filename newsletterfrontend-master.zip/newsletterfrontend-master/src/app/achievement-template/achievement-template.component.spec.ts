import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AchievementTemplateComponent } from './achievement-template.component';

describe('AchievementTemplateComponent', () => {
  let component: AchievementTemplateComponent;
  let fixture: ComponentFixture<AchievementTemplateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AchievementTemplateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AchievementTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
