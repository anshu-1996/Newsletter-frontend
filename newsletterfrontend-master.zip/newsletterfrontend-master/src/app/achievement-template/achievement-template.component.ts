import { Component, OnInit } from '@angular/core';
import { TemplateService } from '../template.service';
import { achievementTemp } from '../user';
import { UserRegistrationService } from '../user-registration.service';

@Component({
  selector: 'app-achievement-template',
  templateUrl: './achievement-template.component.html',
  styleUrls: ['./achievement-template.component.scss']
})
export class AchievementTemplateComponent implements OnInit {

  // title:string='Achievements!';
  // date:string='28/08/21';
  // content1:string='Achievement 1';
  // content2:string='Achievement 2';
  // content3:string='Achievement 3';


  templateId:number = 0;
  template: achievementTemp= new achievementTemp('','',['','',''])
  file:any;

  constructor(private service : UserRegistrationService,private templateService : TemplateService) { }

  ngOnInit(): void {
    this.templateService.fileUploaded.subscribe(()=>{
      // console.log(30);
      if(this.templateService.template===3){
        this.file = this.templateService.getFile();
        this.setDataByFile()
      }
    })

    this.templateService.save.subscribe(()=>{
      if(this.templateService.template===3){
        const data={'templateType':'achievement','title':this.template.title,'date':this.template.date,'achievements':this.template.achievement1,'createdBy':localStorage.getItem('username')};
        this.templateService.onTemplateSave(data,this.templateId).subscribe((data)=>{
          this.file = data;
          this.templateId = this.file.templateId;
        });
      }
    })
  }
  setDataByFile() {
    if(this.templateId===0){
      this.templateId = this.file.templateId;
    }
    this.template.date = this.file.date;
    this.template.title = this.file.title;
    this.template.achievement1 = this.file.achievements;
  }


 // subscribe the save button event on edit template
 onSave()
 {
   this.service.saveTemplate(this.template)
 }



}
