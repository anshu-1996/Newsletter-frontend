import { Component, OnInit} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserRegistrationService } from '../user-registration.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  loggedIn:any;
  router:Router;
  route:ActivatedRoute
  userService: UserRegistrationService;
  constructor(userService:UserRegistrationService,router:Router,route:ActivatedRoute) {
    this.userService = userService;
    this.route = route;
    this.router = router;
    // this.loggedIn = this.userService.loggedIn;
   }

  ngOnInit(): void {
    this.loggedIn = localStorage.getItem('loggedIn');
  }

  Logout(){
    this.loggedIn = localStorage.setItem('loggedIn','false')
    localStorage.removeItem('jwt');
    localStorage.removeItem('username');
    this.router.navigate(['/home']);
  }

}
